import { useEffect, useRef, useState } from 'react'
import * as d3 from 'd3'
import dagreD3 from 'dagre-d3'
import './POSTreeStructure.css'

// Sample data structure - organized by region → store → POS
const sampleData = [
  {
    id: 1,
    name: 'Region North',
    type: 'region',
    children: [
      {
        id: 1001,
        name: 'Store 1001',
        type: 'store',
        children: [
          { id: 100101, name: 'POS-1001-01', type: 'pos', status: 'active' },
          { id: 100102, name: 'POS-1001-02', type: 'pos', status: 'active' },
          { id: 100103, name: 'POS-1001-03', type: 'pos', status: 'inactive' }
        ]
      },
      {
        id: 1002,
        name: 'Store 1002',
        type: 'store',
        children: [
          { id: 100201, name: 'POS-1002-01', type: 'pos', status: 'active' },
          { id: 100202, name: 'POS-1002-02', type: 'pos', status: 'active' }
        ]
      },
      {
        id: 1003,
        name: 'Store 1003',
        type: 'store',
        children: [
          { id: 100301, name: 'POS-1003-01', type: 'pos', status: 'active' },
          { id: 100302, name: 'POS-1003-02', type: 'pos', status: 'inactive' }
        ]
      }
    ]
  },
  {
    id: 2,
    name: 'Region South',
    type: 'region',
    children: [
      {
        id: 2001,
        name: 'Store 2001',
        type: 'store',
        children: [
          { id: 200101, name: 'POS-2001-01', type: 'pos', status: 'active' },
          { id: 200102, name: 'POS-2001-02', type: 'pos', status: 'active' },
          { id: 200103, name: 'POS-2001-03', type: 'pos', status: 'active' }
        ]
      },
      {
        id: 2002,
        name: 'Store 2002',
        type: 'store',
        children: [
          { id: 200201, name: 'POS-2002-01', type: 'pos', status: 'active' },
          { id: 200202, name: 'POS-2002-02', type: 'pos', status: 'inactive' }
        ]
      }
    ]
  },
  {
    id: 3,
    name: 'Region East',
    type: 'region',
    children: [
      {
        id: 3001,
        name: 'Store 3001',
        type: 'store',
        children: [
          { id: 300101, name: 'POS-3001-01', type: 'pos', status: 'active' },
          { id: 300102, name: 'POS-3001-02', type: 'pos', status: 'active' }
        ]
      }
    ]
  }
]

const POSTreeStructure = () => {
  const svgRef = useRef(null)

  // Get all stores from data for filter dropdown
  const getAllStores = () => {
    const stores = []
    sampleData.forEach(region => {
      region.children.forEach(store => {
        stores.push({ id: store.id, name: store.name, region: region.name })
      })
    })
    return stores
  }

  const allStores = getAllStores()

  // Default to first store
  const [selectedStore, setSelectedStore] = useState(allStores[0]?.id.toString() || '')

  useEffect(() => {
    if (!svgRef.current || !selectedStore) return

    // Clear previous graph
    d3.select(svgRef.current).selectAll('*').remove()

    // Find the selected store and create filtered data
    const storeId = parseInt(selectedStore)
    let filteredData = null

    sampleData.forEach(region => {
      region.children.forEach(store => {
        if (store.id === storeId) {
          filteredData = [store] // Only show the selected store
        }
      })
    })

    const dataToRender = filteredData || []

    // Create a new directed graph
    const g = new dagreD3.graphlib.Graph().setGraph({
      rankdir: 'TB', // Top to bottom
      nodesep: 80,
      ranksep: 100,
      marginx: 40,
      marginy: 40
    })

    // Function to get icon for node type
    const getIcon = (type) => {
      switch (type) {
        case 'region': return '🌐'
        case 'store': return '🏪'
        case 'pos': return '💻'
        default: return '📄'
      }
    }

    // Function to get node class for styling
    const getNodeClass = (node) => {
      let classes = `node-${node.type}`
      if (node.status) {
        classes += ` status-${node.status}`
      }
      return classes
    }

    // Recursively add nodes and edges from hierarchical data
    const addNodesAndEdges = (nodes, parentId = null) => {
      nodes.forEach(node => {
        const nodeId = String(node.id)

        // Create label HTML with icon and status
        let labelHtml = `
          <div class="d3-node-content">
            <span class="d3-node-icon">${getIcon(node.type)}</span>
            <span class="d3-node-name">${node.name}</span>
            ${node.status ? `<span class="d3-status-badge ${node.status}">${node.status}</span>` : ''}
          </div>
        `

        // Add node to graph
        g.setNode(nodeId, {
          labelType: 'html',
          label: labelHtml,
          class: getNodeClass(node),
          rx: 12,
          ry: 12
        })

        // Add edge from parent if exists
        if (parentId) {
          g.setEdge(String(parentId), nodeId, {
            curve: d3.curveBasis,
            arrowhead: 'vee'
          })
        }

        // Recursively add children
        if (node.children && node.children.length > 0) {
          addNodesAndEdges(node.children, node.id)
        }
      })
    }

    // Build the graph
    addNodesAndEdges(sampleData)

    // Create the renderer
    const render = new dagreD3.render()

    // Set up an SVG group so that we can translate the final graph
    const svg = d3.select(svgRef.current)
    const svgGroup = svg.append('g')

    // Run the renderer
    render(svgGroup, g)

    // Get graph dimensions
    const graphWidth = g.graph().width
    const graphHeight = g.graph().height
    const svgWidth = parseInt(svg.style('width'))
    const svgHeight = parseInt(svg.style('height'))

    // Center the graph
    const xCenterOffset = (svgWidth - graphWidth) / 2
    const yCenterOffset = 40

    svgGroup.attr('transform', `translate(${xCenterOffset}, ${yCenterOffset})`)

    // Set SVG dimensions
    svg.attr('height', graphHeight + 80)

    // Add zoom behavior
    const zoom = d3.zoom()
      .scaleExtent([0.5, 2])
      .on('zoom', (event) => {
        svgGroup.attr('transform', event.transform)
      })

    svg.call(zoom)

  }, [selectedStore])

  return (
    <div className="pos-tree-container">
      <div className="tree-header">
        <h2>POS Machine Hierarchy</h2>
        <p>View the parent-child relationship of POS machines across regions and stores</p>
      </div>

      <div className="tree-controls">
        <div className="filter-group">
          <label htmlFor="store-filter">Select Store:</label>
          <select
            id="store-filter"
            className="store-filter-select"
            value={selectedStore}
            onChange={(e) => setSelectedStore(e.target.value)}
          >
            {allStores.map(store => (
              <option key={store.id} value={store.id}>
                {store.name} ({store.region})
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="tree-view-d3">
        <svg ref={svgRef} width="100%" height="800"></svg>
      </div>
    </div>
  )
}

export default POSTreeStructure
