# POS Management System

A React application for managing and tracking POS machines with message delivery monitoring.

## Features

### 1. POS Tree Structure Tab
- Displays hierarchical view of POS machines organized by:
  - Regions
  - Clusters
  - Stores
  - Individual POS machines
- Expandable/collapsible tree navigation
- Visual status indicators (active/inactive)
- Interactive UI with hover effects

### 2. Message Tracker Tab
- Track message delivery across stores and POS machines
- Two tracking modes:
  - **Store Mode**: Enter a specific store number to track
  - **Cluster Mode**: Select a cluster and multiple stores

#### Message Tracker Features:
- Message key input for tracking
- Cluster selection dropdown
- Multi-select store checkboxes with "Select All" option
- **Overview Dashboard**:
  - Overall statistics showing total POS count
  - Status breakdown: Delivered, Processing, Pending, Failed
  - Visual progress bar
- **Drill-down Capability**:
  - Store-level summary cards with quick stats
  - Expandable store details showing individual POS machines
  - Detailed table view with:
    - POS machine names
    - Status indicators
    - Last update timestamps
    - Retry attempts

## Getting Started

### Prerequisites
- Node.js 20.19+ or 22.12+ (currently works with 20.18.1 but shows a warning)
- npm

### Installation

1. Navigate to the project directory:
```bash
cd pos-message-tracker
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to:
```
http://localhost:5173/
```

## Usage

### POS Tree Structure
1. Click on the "POS Tree Structure" tab
2. Use the expand/collapse buttons (▶/▼) to navigate the hierarchy
3. View POS machine status (active/inactive) with color-coded indicators

### Message Tracker
1. Click on the "Message Tracker" tab
2. Enter a message key (e.g., "UPDATE_CONFIG_001")
3. Choose tracking mode:
   - **Store**: Enter a store number directly
   - **Cluster**:
     - Select a cluster from the dropdown
     - Choose one or multiple stores (or select all)
4. Click "Track Message"
5. View results:
   - Review overall statistics at the top
   - Click on store cards to expand and see individual POS machine details
   - Check status, timestamps, and retry attempts for each POS

## Technology Stack

- **React** - UI framework
- **Vite** - Build tool and development server
- **CSS3** - Styling with modern features (Grid, Flexbox, Gradients)

## Project Structure

```
pos-message-tracker/
├── src/
│   ├── components/
│   │   ├── POSTreeStructure.jsx
│   │   ├── POSTreeStructure.css
│   │   ├── MessageTracker.jsx
│   │   └── MessageTracker.css
│   ├── App.jsx
│   ├── App.css
│   ├── index.css
│   └── main.jsx
├── public/
├── package.json
└── README.md
```

## Features Explained

### Visual Indicators
- **Delivered** (Green): Message successfully delivered
- **Processing** (Blue): Message is being processed
- **Pending** (Orange): Message waiting to be sent
- **Failed** (Red): Message delivery failed

### Interactive Elements
- Expandable tree nodes
- Collapsible store cards
- Hover effects for better UX
- Responsive design for mobile devices

## Future Enhancements

- Real API integration (currently uses mock data)
- Real-time updates via WebSockets
- Export functionality for reports
- Advanced filtering and search
- Historical message tracking
- Notification system for failed deliveries
- User authentication and authorization

## Build for Production

```bash
npm run build
```

The production-ready files will be generated in the `dist/` directory.

## Development

```bash
npm run dev    # Start development server
npm run build  # Build for production
npm run preview # Preview production build
```

## License

MIT
